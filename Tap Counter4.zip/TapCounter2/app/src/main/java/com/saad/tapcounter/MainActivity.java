package com.saad.tapcounter;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.preference.PreferenceManager;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

public class MainActivity extends AppCompatActivity {

    private AdView mAdView ;
    int Start;
    TextView txt;
    Button btnU,btnT,btnR;
    Switch sw,sw2;
    private ConstraintLayout Clayout;
    Vibrator vibe;
    Boolean switchPref;
    String edtcounter;
    Boolean Cb1;

    SharedPreferences sharedPreferences;

    private static long back_pressed;

    @Override
    public void onResume() {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        switchPref = prefs.getBoolean("Switchsett1", false);
        //Toast.makeText(this, String.valueOf(switchPref), Toast.LENGTH_SHORT).show();
        edtcounter = prefs.getString("edtcounter", "0");
        Cb1 = prefs.getBoolean("Cb1", false);
        super.onResume();
    }

    //Double Tap Exit
    @Override
    public void onBackPressed()
    {
        if (back_pressed + 2000 > System.currentTimeMillis()) super.onBackPressed();
        else Toast.makeText(getBaseContext(), "Press once again to exit!", Toast.LENGTH_SHORT).show();
        back_pressed = System.currentTimeMillis();
    }


    //Inflater for Menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu,menu);
        return true;

    }

    //Menu
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()){
            case R.id.menui1:
                startActivity(new Intent(this, SettingsActivity.class));

                return true;


            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Toolbar toolbar = findViewById(R.id.toolbarid);
        setSupportActionBar(toolbar);



        MobileAds.initialize(this, "ca-app-pub-3940256099942544/6300978111");
        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        vibe =(Vibrator)getSystemService(VIBRATOR_SERVICE);
        Clayout = findViewById(R.id.MainLayout);
        btnT =  findViewById(R.id.tapbtn);
        btnR =  findViewById(R.id.resetbtn);
        btnU =  findViewById(R.id.undobtn);
        sw = findViewById(R.id.swch);
        sw2 = findViewById(R.id.darkswch);
        txt =  findViewById(R.id.txtv);
        txt.setTextColor(Color.BLACK);
        sharedPreferences = getSharedPreferences("0",MODE_PRIVATE);

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        switchPref = prefs.getBoolean("Switchsett1", false);
        //Toast.makeText(this, String.valueOf(switchPref), Toast.LENGTH_SHORT).show();
        edtcounter = prefs.getString("edtcounter", "0");
        Cb1 = prefs.getBoolean("Cb1", false);


        loadData();
        setData();
        incrementbtn();
        undobtn();
        resetbtn();
        switchbtn();
        themeswitch();

    }
    public void loadData(){
        sharedPreferences = getSharedPreferences("0",MODE_PRIVATE);
    }

    private void setData(){
        Start = sharedPreferences.getInt("0",0);
        if(Start==0){
            txt.setText("0");
        }
        else{
            txt.setText(Integer.toString(Start));
        }
    }

    public void incrementbtn(){
        btnT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                incvibe();
                if (Start != 0) {
                    Start = sharedPreferences.getInt("0", 0);
                    Start += 1;
                    txt.setText(Integer.toString(Start));
                    txtresize();
                } else {
                    Start += 1;
                    txt.setText(Integer.toString(Start));
                }
                alertnum();
                sharedPreferences.edit().putInt("0", Start).apply();
            }
        });
    }

    public void undobtn(){
        btnU.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                undovibe();
                if (Start != 0) {
                    Start = sharedPreferences.getInt("0", 0);
                    Start -= 1;
                    txt.setText(Integer.toString(Start));
                }
                else{
                    return;
                }
                sharedPreferences.edit().putInt("0", Start).apply();
            }
        });
    }

    public void resetbtn(){
        btnR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetvibe();
                Start = 0;
                txt.setText(Integer.toString(Start));
                sharedPreferences.edit().putInt("0", Start).apply();

            }
        });
    }

    public void switchbtn(){
        sw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(sw.isChecked()) {
                    btnR.setEnabled(false);
                    btnT.setEnabled(false);
                    btnU.setEnabled(false);
                    txt.setTextColor(Color.RED);
                }
                else{
                    btnR.setEnabled(true);
                    btnT.setEnabled(true);
                    btnU.setEnabled(true);
                    if(sw2.isChecked()){
                        txt.setTextColor(Color.WHITE);
                    }
                    else{
                        txt.setTextColor(Color.BLACK);
                    }
                }
            }
        });
    }

    public void themeswitch(){
        sw2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(sw2.isChecked()){
                    Clayout.setBackgroundColor(Color.DKGRAY);

                    if(sw.isChecked()){
                        txt.setTextColor(Color.RED);
                    }
                    else{
                        txt.setTextColor(Color.WHITE);
                    }
                }
                else{
                    Clayout.setBackgroundColor(Color.WHITE);
                    if(sw.isChecked()){
                        txt.setTextColor(Color.RED);
                    }
                    else{
                        txt.setTextColor(Color.BLACK);
                    }

                }
            }
        });

    }

    public void txtresize(){

        if(Start > 1000 && Start < 10000){
            txt.setTextSize(80);
        }
        else if (Start > 10000 && Start < 100000){
            txt.setTextSize(60);
        }
        else if (Start > 100000){
            txt.setTextSize(40);
        }
        else{
            return;
        }
    }

    public void undovibe(){
        if(switchPref){
            vibe.vibrate(100);
        }
        else{
            vibe.vibrate(0);
        }
    }

    public void resetvibe(){
        if(switchPref){
            vibe.vibrate(150);
        }
    }

    public void incvibe(){
        if(switchPref){
            vibe.vibrate(50);
        }
    }
    
    public void alertnum(){
        if((Integer.parseInt(edtcounter) == Start) && (Cb1)){
            vibe.vibrate(2000);
        }
    }
}//Real one
